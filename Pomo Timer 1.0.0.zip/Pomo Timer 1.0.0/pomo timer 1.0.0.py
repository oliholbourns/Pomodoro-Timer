import tkinter
from tkinter import *
import time
import pygame

global seconds
seconds=1
minutes = 0

root=Tk()
root.title('Pomodoro timer')
root.geometry("400x400")
root.config(bg = "cyan")

global tasknum
tasknum = 0

global option1
option1 = True
global option2
option2 = True
global option3
option3 = True
global option4
option4 = True
global option5
option5 = True

label1 = Label(root, text="Choose timer length (Minutes)", bg="cyan", fg="black", font="none 16")
label1.grid(row=0, column=0, sticky=N)
label1.config(justify="center")

#music
pygame.mixer.init()
def play():
    pygame.mixer.music.load("Pomo timer/Pomo alarm.mp3")
    pygame.mixer.music.play()
    

def two_minutes():
    label1.config(text="Time remaining:")
    label1.update()
    timer = Label(root, text="", bg="cyan", fg="white", font="none 45")
    timer.grid(row=1,column=0, sticky=N)
    seconds=120
    while seconds != 0:
        true_seconds = 60
        while seconds > 60:
            seconds = seconds - 1
            minutes = 1
            true_seconds = true_seconds - 1
            time.sleep(1)
            if true_seconds < 10:
                timer.config(text=str(minutes) + ":" + "0" + str(true_seconds))
                timer.update()
            else:
                timer.config(text=str(minutes) + ":" + str(true_seconds))
                timer.update()
        true_seconds=60
        while seconds != 0:
            seconds = seconds - 1
            minutes=0
            true_seconds = true_seconds - 1
            time.sleep(1)
            if true_seconds < 10:
                timer.config(text=str(minutes) + ":" + "0" + str(true_seconds))
                timer.update()
            else:
                timer.config(text=str(minutes) + ":" + str(true_seconds))
                timer.update()
    if seconds == 0:
        play()

def five_minutes():
    label1.config(text="Time remaining:")
    label1.update()
    timer = Label(root, text="", bg="cyan", fg="white", font="none 45")
    timer.grid(row=1,column=0, sticky=N)
    seconds=300
    while seconds != 0:
        true_seconds=60
        while seconds > 240:
            seconds = seconds - 1
            minutes = 4
            true_seconds = true_seconds - 1
            time.sleep(1)
            if true_seconds < 10:
                timer.config(text=str(minutes) + ":" + "0" + str(true_seconds))
                timer.update()
            else:
                timer.config(text=str(minutes) + ":" + str(true_seconds))
                timer.update()
        true_seconds=60
        while seconds > 180:
            seconds = seconds - 1
            minutes = 3
            true_seconds = true_seconds - 1
            time.sleep(1)
            if true_seconds < 10:
                timer.config(text=str(minutes) + ":" + "0" + str(true_seconds))
                timer.update()
            else:
                timer.config(text=str(minutes) + ":" + str(true_seconds))
                timer.update()
        true_seconds=60
        while seconds > 120:
            seconds = seconds - 1
            minutes = 2
            true_seconds = true_seconds - 1
            time.sleep(1)
            if true_seconds < 10:
                timer.config(text=str(minutes) + ":" + "0" + str(true_seconds))
                timer.update()
            else:
                timer.config(text=str(minutes) + ":" + str(true_seconds))
                timer.update()
        true_seconds=60
        while seconds > 60:
            seconds = seconds - 1
            minutes = 1
            true_seconds = true_seconds - 1
            time.sleep(1)
            if true_seconds < 10:
                timer.config(text=str(minutes) + ":" + "0" + str(true_seconds))
                timer.update()
            else:
                timer.config(text=str(minutes) + ":" + str(true_seconds))
                timer.update()
        true_seconds=60
        while seconds != 0:
            seconds = seconds - 1
            minutes = 0
            true_seconds = true_seconds - 1
            time.sleep(1)
            if true_seconds < 10:
                timer.config(text=str(minutes) + ":" + "0" + str(true_seconds))
                timer.update()
            else:
                timer.config(text=str(minutes) + ":" + str(true_seconds))
                timer.update()
    if seconds == 0:
        play()

def add():
    global option1
    global option2
    global option3
    global option4
    global option5
    if option1 == True:
        adding = add_task.get()
        task1.config(text="- " + str(adding))
        task1.update()
        add_task.delete(0, END)
        option1 = False
    elif option2 == True:
        adding = add_task.get()
        task2.config(text="- " + str(adding))
        task2.update()
        add_task.delete(0, END)
        option2 = False
    elif option3 == True:
        adding = add_task.get()
        task3.config(text="- " + str(adding))
        task3.update()
        option3 = False
        add_task.delete(0, END)
    elif option4 == True:
        adding = add_task.get()
        task4.config(text="- " + str(adding))
        task4.update()
        option4 = False
        add_task.delete(0, END)
    elif option5 == True:
        adding = add_task.get()
        task5.config(text="- " + str(adding))
        task5.update()
        option5 = False
        add_task.delete(0, END)

def exit_timer():
    root.destroy()

twomins = Button(root, text="2 minutes", width=15, bg="cyan", font="none 16", command=two_minutes)
twomins.grid(row=2, column=0, sticky=N)
twomins.config(justify="center")

fivemins = Button(root, text="5 minutes", width=15, bg="cyan", font="none 16", command=five_minutes)
fivemins.grid(row=4, column=0, sticky=N)
fivemins.config(justify="center")

exitbutton = Button(root, text="Exit", width=15, bg="cyan", font="none 16", command=exit_timer)
exitbutton.grid(row=5, column=0, sticky=N)
exitbutton.config(justify="center")

Label(root, text="", bg="cyan") .grid(row=6, column=0, sticky=N)
Label(root, text="Tasks", bg="cyan", fg="black", font= "none 16") .grid(row=7, column=0, sticky=N)
add_task = Entry(root, bg="white")
add_task.grid(row=8, column = 0, sticky=W)
Button(root, text="Add", bg="white", font="none 16", command=add) .grid(row=8, column=0, sticky=E)


task1 = Label(root, text="-", bg="cyan")
task1.grid(row=9, column=0, sticky=W)

task2 = Label(root, text="-", bg="cyan")
task2.grid(row=10, column=0, sticky=W)

task3 = Label(root, text="-", bg="cyan")
task3.grid(row=11, column=0, sticky=W)

task4 = Label(root, text="-", bg="cyan")
task4.grid(row=12, column=0, sticky=W)

task5 = Label(root, text="-", bg="cyan")
task5.grid(row=13, column=0, sticky=W)

def complete1():
    task1.config(text="-")
    task1.update()
    global option1
    option1 = True
    
def complete2():
    task2.config(text="-")
    task2.update()
    global option2
    option2 = True

def complete3():
    task3.config(text="-")
    task3.update()
    global option3
    option3 = True

def complete4():
    task4.config(text="-")
    task4.update()
    global option4
    option4 = True

def complete5():
    task5.config(text="-")
    task5.update()
    global option5
    option5 = True
    
Button(root, text ="✅", width=1, bg="white", command=complete1) .grid(row=9, column=1, sticky = W)
Button(root, text ="✅", width=1, bg="white", command=complete2) .grid(row=10, column=1, sticky = W)
Button(root, text ="✅", width=1, bg="white", command=complete3) .grid(row=11, column=1, sticky = W)
Button(root, text ="✅", width=1, bg="white", command=complete4) .grid(row=12, column=1, sticky = W)
Button(root, text ="✅", width=1, bg="white", command=complete5) .grid(row=13, column=1, sticky = W)

root.mainloop()
